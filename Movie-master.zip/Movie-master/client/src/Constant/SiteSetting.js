// import Images from "./Images";
const SiteSetting = [
  {
    FB_link: "#",
    TW_link: "#",
    Phone: "#",
    Email: "#",
    Printrest: "#",
    Site_Link: "#",
    Copyright_text: "© 2021 NerdHerd. All Rights Reserved",
    Design_by:
      "Designed And Developed By <a target='_blank' href='#'>Jalon Young</a>",
    // Logo: Images.Logo,
    // Logomin: Images.Logomin,
    LogoSlogan: "Movie Master",
  },
];
export default {
  SiteSetting,
};
