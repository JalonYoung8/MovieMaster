// import Robot from "../assets/img/1.png";
// export default {
//   Robot,
// };
